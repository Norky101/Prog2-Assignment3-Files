import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
public class TA extends Student
{

public TA ( String sPosition, String sName, long sId,long sPhone)
{
    super( sPosition, sName,sId,sPhone);
}

@Override
    public int getID() // returns max val of Sid or Tid
    {

        return super.getID();
    }

    @Override
    public void CSVPrintln(PrintWriter out)
    {
        out.println(getName() + "," + getID() + "," + sPhone);
//
    }
}//end of TA  class

