import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Teacher implements CSVPrintable
{

private String tName;
private String tPosition;
private long tId;
private long tPhone;
// Default constructor

        Teacher()
        {
                this.tName = "";
                this.tPosition = "";
                this.tId = 0L;
                this.tPhone = 0L;

        }
        // Custom constructor
        Teacher( String tPosition, String tName, long tId, long tPhone)
        {
                this.tName = tName;
                this.tPosition =tPosition;
                this.tId = tId;
                this.tPhone = tPhone;
        }

//Setters
public void tFirstname()
        {
        this.tName = tName;
        }
public void tPosition()
        {
        this.tPosition = tPosition;
        }
public void tId()
        {
        this.tId = tId;
        }
public void tPhone()
        {
        this.tPhone = tPhone;
        }

//getters
public String getName()// return firstname,lastname
        {

        return tName;
        }

        @Override
        public int getID()
        {
                int inttId =(int)tId;
                return inttId;
        }

public void CSVPrintln(PrintWriter out)
{
//        PrintWriter writer = null;
//        try {
//                writer = new PrintWriter(new FileWriter("out.csv"));
//        } catch (IOException e)
//        {
//                e.printStackTrace();
//        }
        out.println(getName() + "," + getID() + "," + tPhone);
       // writer.close();
        //send info to File on a newline
}

}//end of Teacher  class
