import java.io.PrintWriter;

public interface CSVPrintable
{
    public String getName();
    public int getID();
    public void CSVPrintln(PrintWriter out);

}
//end of CSVPrintable Interface class
