import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

//Student Jj,kk 54321 0 9876543211
//Teacher Bill,JJ 0 12345 1234567891
public class Main
{
    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("Welcome!"); // intro line

        Scanner scanner1 = new Scanner(System.in);
        // amount of lines to be addded to file
        System.out.println("How many rows of data do you want to input?");
        int inputAmount = scanner1.nextInt();

        // create  file
        File output = new File("out.csv");  // create file with specific name

        PrintWriter CSVWriter= new PrintWriter(output);  // file object
        CSVWriter.write(inputAmount); // add number of lines to file

        int rows = 0;
        //creating object from CSVPrintable to add info to specific classes

        // while loop to check input
        while (rows < inputAmount)// while  row not < numrows
        {
            CSVPrintable classify;

            // Get information for row
            Scanner scanner2 = new Scanner(System.in);
            System.out.println("Please enter the information using the following format: 'Position FirstName,LastName StudentIDNumber TeacherIDNumber PhoneNumber'.");
            String input = scanner2.nextLine();

            String[] parts = input.split(" ");
            String position = parts[0];
            String name = parts[1];
            long StudentId = Long.parseLong(parts[2]); //converts string to int  //Long
            long TeacherId = Long.parseLong(parts[3]);  //converts string to int  // Long
            long phone = Long.parseLong(parts[4]); // converts string to int

            if (!isValid(position,name, (int) StudentId, (int) TeacherId,(int) phone)) //repeats until true
            {

                System.out.println("Invalid input. Please enter the information again using the correct format.");

            }
            else  //if true
            {
                // When True ( correct input)
                rows += 1;

                // if passed valid check, assign to constructor for relevant object
                if (position.equalsIgnoreCase("Student"))
                {
                    //Create Student
                    // Adds values to Class objects.
                    //Student studentObj = new Student(position, name, StudentId, phone);
                   // studentObj.CSVPrintln(CSVWriter);
                    classify = new Student(position, name, StudentId, phone);
                } else if (position.equalsIgnoreCase("Teacher"))
                {
                    //Create Teacher
                    classify = new Teacher(position, name, StudentId, phone);

                   // Teacher teacherObj = new Teacher(position, name, StudentId, phone);
                   // teacherObj.CSVPrintln(CSVWriter);
                } else
                {
                    // Create  TA
                    classify = new TA(position, name, StudentId, phone);

                    //TA TaObj = new TA(position, name, StudentId, phone);
                    //TaObj.CSVPrintln(CSVWriter);
                }
                classify.CSVPrintln(CSVWriter);

            }
        }//end of While loop
        CSVWriter.close(); //close file
        System.out.println("Program complete, you have entered "+ inputAmount +" rows"); // end message

    }// end of Main method

    private static boolean isValid(String position, String name, long StudentId, long TeacherId, int phone)
    {
        //perform checks
        // 1. Check which position as this determines which things we check
        if (position.equalsIgnoreCase("Student"))
        {
            // do Student checks
            try {
                name = name.replace(",", " ");
            } catch (Exception e) // ‘e’ is just the variable used for if we want to call Exception methods
            {
                System.out.println("Student name error");
                return false;
            }

            //String phoneStr = Integer.toString(phone); //convert to int
            if ((Long.toString(phone)).length() != 10)
            {
                System.out.println("Student phone number error");
                return false;
            }
            //String StudentIdStr = Integer.toString(StudentId);
            if ((Long.toString(StudentId)).length() != 5)
            {
                System.out.println("StudentId error");
                return false;
            }

            TeacherId = 0;
            return true;
        }

        else if (position.equalsIgnoreCase("Teacher")) {
            //do Teacher checks
            try {
                name = name.replace(",", " ");
            } catch (Exception e) // ‘e’ is just the variable used for if we want to call Exception methods
            {
                System.out.println("Teacher name error");
                return false;
            }

            //String phoneStr = Integer.toString(phone);
            if ((Long.toString(phone)).length() != 10)
            {
                System.out.println("Teacher phone number error");
                return false;
            }
            //String TeacherIdStr = Integer.toString(TeacherId);
            if (Long.toString(TeacherId).length() != 5)
            {
                System.out.println("TeacherId error");
                return false;

            }
            StudentId = 0;
            return true;

        }
         else if (position.equalsIgnoreCase("TA"))
        {
            // do TA checks
            try {
                name = name.replace(",", " ");
            } catch (Exception e) // ‘e’ is just the variable used for if we want to call Exception methods
            {
                System.out.println("TA name error");
                return false;
            }

           // String phoneStr = Integer.toString(phone);
            if (Long.toString(phone).length() != 10)
            {
                System.out.println("TA phone number error");
                return false;
            }
            //String TeacherIdStr = Integer.toString(TeacherId);
            if (Long.toString(TeacherId).length() != 5)
            {
                System.out.println("TA Id error");
                return false;
            }
            return true;
        }
        else
        {
        System.out.println("Re-enter position ");
        //wrong input
        // display error with why
        // reset rows count
        return false;
        }
    }//end of IsValid()

}//end of Main class