import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Student implements CSVPrintable
{
    private String sName;
    private String sPosition;
    private long sId;
    public long sPhone;

    // Default constructor

    public Student()
    {
        this.sPosition = "";
        this.sName = "";
        this.sId = 0L;
        this.sPhone = 0L;

    }
    // Custom constructor
    public Student(String sPosition,String sName, long sId,long sPhone)
    {
        this.sPosition =sPosition;
        this.sName = sName;
        this.sId = sId;
        this.sPhone = sPhone;
    }



    //Setters
    public void sFirstname()
        {
            this.sName = sName;
        }
    public void sPosition()
        {
        this.sPosition = sPosition;
        }
    public void sId()
        {
        this.sId = sId;
        }
    public void sPhone()
        {
        this.sPhone = sPhone;
        }

    //getters
    public String getName()// return firstname,lastname
        {

            return sName;
        }

    @Override
    public int getID() {
        int inttId = (int) sId; // converts long to int
        return inttId;
    }

    public void CSVPrintln(PrintWriter out)
        {
//            PrintWriter writer = null;
//            try {
//                writer = new PrintWriter(new FileWriter("out.csv"));
//            } catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//            writer.println(getName() + "," + getID() + "," + sPhone+ "\n");
            //writer.close();
            //send info to File on a newline
            out.println(getName() + "," + getID() + "," + sPhone);
        }
        
}//end of Student class
